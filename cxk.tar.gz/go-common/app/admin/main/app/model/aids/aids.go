package aids

// Param param
type Param struct {
	Aid  int64
	Aids string `form:"aids"`
}
