#### app-admin app管理后台

##### 项目简介
> 1.提供主站app manager管理

##### 编译环境
> 请只用golang v1.8.x以上版本编译执行。

##### 依赖包
> 1.公共包go-common
