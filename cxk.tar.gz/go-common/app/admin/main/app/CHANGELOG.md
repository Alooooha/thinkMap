#### app-admin app管理后台

### Version 1.0.2
> 1.APP底部入口
> 2.版本管理/添加AV号
> 3.删除SQL多余字段

### Version 1.0.1

> 1.增加BFS文件上传
> 2.BFS文件上传Message修改
> 3.公共管理
> 4.语言管理
> 5.app墙
> 6.修复bm内网浏览器调用问题

### Version 1.0.0

> 1.App审核版本管理