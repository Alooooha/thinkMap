# filter-admin

## 项目简介
> 提供内容过滤服务的后台接口

## 编译环境
> 请只用golang v1.8.x以上版本编译执行。  

## 依赖包
> 1.公共包go-common  
