package search

import (
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestFake(t *testing.T) {
	Convey("fake", t, func() {
		t.Log("fake log")
	})
}
