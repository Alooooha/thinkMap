# v1.3.4
1. fix ConKeyByID

# v1.3.3
1. edit AI host

# v1.3.2
1. modify habase sdk

# v1.3.1
1. fix admin ai bm

# v1.3.0
1. http router to bm

# v1.2.0
1. ai垃圾信息过滤模型接入 

# v1.1.6
1. 修复编辑key敏感词不清真

# v1.1.5
1. 修复编辑key敏感词时，cache未清除的bug 
 
# v1.1.4
1. rows close

# v1.1.3
1. 修复插入敏感词内容与弹幕冲突
# v1.1.2
1. remove stastd

# v1.1.1
1. 修复admin list接口

# v1.1.0
1. 直播后台改造
http api新增：
/x/admin/filter/area/group/list
/x/admin/filter/area/group/add
/x/admin/filter/area/list
/x/admin/filter/area/add
/x/admin/filter/area/edit
/x/admin/filter/area/log
http api修改：
/x/admin/filter/add
/x/admin/filter/edit
2. 弹幕添加弹幕，增加白样本检测 

# v1.0.2
1. 优化、增加单元测试

## v1.0.3
1. 弹幕录入增加白样本检测
2. 禁止正则加入.*和||
 
## v1.0.2
1. 优化、增加单元测试

# v1.0.1
1. 添加白名单notify

# v1.0.0
1. 初始化 